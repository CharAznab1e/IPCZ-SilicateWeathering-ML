% =========================================================================
% MULTI-MODEL ENSEMBLE WEATHERING FLUX PREDICTION
% =========================================================================
% This MATLAB code accompanies the manuscript:
% "Rainfall amplified sea-level control on silicate weathering in the 
%  Indo-Pacific Convergence Zone during Quaternary glacials"
% 
% Target Journal: Communications Earth & Environment
% Current Status: Under review (as of when this comment was written)
%
% IMPORTANT: Please do not cite or distribute this code until the 
%            associated manuscript is formally published. We will update
%            this repository's README upon publication, at which point we
%            warmly welcome its use and citation. If I remember, I'll also
%            update this very comment — but the README will be the 
%            definitive source for current information.
%
% PROGRAM DESCRIPTION:
% This program implements a multi-model ensemble approach to predict
% silicate weathering fluxes in the Indo-Pacific Convergence Zone (IPCC)
% using five different machine learning models. The ensemble uses R²-weighted 
% averaging to combine predictions from:
% 1. Deep Learning (GANs-GRU-LSTM)
% 2. Bagging (Bootstrap Aggregating)
% 3. Random Forest
% 4. Support Vector Machine (SVM)
% 5. Boosting (Gradient Boosting)
%
% Model weights are determined by their respective test R² scores, ensuring
% that better-performing models contribute more to the final prediction.
%
% SPECIFIC APPLICATION:
% This program is designed to predict silicate chemical weathering fluxes
% in the Indo-Pacific Convergence Zone during Quaternary glacial cycles.
%
% INPUT DATA REQUIREMENTS:
% - Sea level (relative to present)
% - Temperature (global mean or regional)
% - Atmospheric CO2 concentration
%
% OUTPUTS:
% - Individual model predictions
% - Weighted ensemble prediction
% - Prediction uncertainty range (min-max across models)
%
% =========================================================================
% CUSTOMIZATION NOTE:
% =========================================================================
% This program is designed for our specific research application. For 
% adaptation to other datasets or regions, users will need to modify:
% 1. Input file paths (currently hard-coded)
% 2. Input variable selection (sea level, temperature, CO2)
% 3. Model training procedures (if using different models)
% 4. Normalization parameters (if using different scaling)
%
% The code structure is modular to facilitate these modifications.
% =========================================================================
% CONTACT:
% =========================================================================
% For scientific questions or collaboration inquiries, please contact the
% corresponding authors:
%   zhaokaixu@qdio.ac.cn  OR  zhaodebo@qdio.ac.cn
%
% For informal chats, bug reports, or code-related questions, feel free to
% reach out to the code author (that's me!):
%   yangyifei@qdio.ac.cn
% =========================================================================

clear; clc; close all;

%% ============================
% SECTION 1: MODEL LOADING
% ============================
% Load pre-trained machine learning models and their performance metrics
% Navigate to the models directory
% Change this path to point to your own Machine Learning Models folder
cd('..\Machine Learning Models')  % Navigate to the Machine Learning Models folder path

% Deep Learning Model (GANs-GRU-LSTM)
GANs_GRU_LSTM = load('GANs_GRU_LSTM.mat');
DPmodel = GANs_GRU_LSTM.net;
R2_DP = GANs_GRU_LSTM.r2_test;

% Bagging Model
Bag = load('Bag.mat');
BagModel = Bag.finalModel;
R2_Bag = Bag.r2;

% Support Vector Machine Model
SVM = load('SVM.mat');
SVMModel = SVM.SVMModel;
R2_SVM = SVM.R2_test;

% Random Forest Model
RandomForest = load('RandomForest.mat');
RFmodel = RandomForest.rfModel;
R2_RF = RandomForest.R2_test;

% Boosting Model
Boosting = load('Boosting.mat');
BoostingModel = Boosting.finalModel;
R2_Boosting = Boosting.r2;

% Load training data for normalization reference
% This dataset is used for reverse normalization of predictions
dataset = xlsread('ModelInput.xlsx');
DataY = dataset(:,4); % Target weathering flux values (used for denormalization)

%% ============================
% SECTION 2: DATA PREPARATION
% ============================
% Load and prepare input data for prediction
% Input variables: Age, CO2, Temperature, Sea Level

% TEST DATA SOURCE:
% This test dataset is derived from:
% Willeit, Matteo; Ganopolski, Andrey; Calov, Reinhard; Brovkin, Victor (2019):
% Global mean CO2, temperature and sea level data from transient model 
% simulations of Quaternary glacial cycles.
% PANGAEA, https://doi.org/10.1594/PANGAEA.902277
%
% NOTE: This data is for testing purposes only. For scientific applications,
% please use appropriate paleoclimate reconstructions as described in our
% manuscript.

clim = xlsread('Clim.xlsx');
clim = flip(clim); % Reverse chronological order if needed

% Extract individual variables
sealevel_input = clim(:,5);
age_input = clim(:,1);
co2_input = clim(:,2);
temp_input = clim(:,3);

% Select time period (e.g., last 700 kyr)
idx = find(age_input <= 700);
age = age_input(idx);
co2 = co2_input(idx);
temp = temp_input(idx);
sealevel = sealevel_input(idx);

% Create feature matrix
X = [sealevel, temp, co2];

%% ============================
% SECTION 3: MODEL PREDICTIONS
% ============================

% Deep Learning Model Prediction
X_normalized = normalize(X, "range");
num_samples = size(X_normalized, 1);
X_cell = cell(num_samples, 1);
for i = 1:num_samples
    X_cell{i} = X_normalized(i, :)';
end
Y_DP = predict(DPmodel, X_cell);
Y_DP = cell2mat(Y_DP)';
Result_DP = Y_DP * (max(DataY) - min(DataY)) + min(DataY);

% Bagging Model Prediction
Result_Bag = predict(BagModel, X);

% SVM Model Prediction
Result_SVM = predict(SVMModel, X);

% Random Forest Model Prediction
Result_RF = predict(RFmodel, X);

% Boosting Model Prediction
Result_Boosting = predict(BoostingModel, X);

%% ============================
% SECTION 4: ENSEMBLE WEIGHTING
% ============================
% Calculate R²-weighted ensemble average

R2_values = [R2_DP, R2_Bag, R2_RF, R2_SVM, R2_Boosting];
weights = R2_values / sum(R2_values);

% Weighted ensemble prediction
Y_weighted = weights(1) * Result_DP' + ...
             weights(2) * Result_Bag + ...
             weights(3) * Result_RF + ...
             weights(4) * Result_SVM + ...
             weights(5) * Result_Boosting;

%% ============================
% SECTION 5: VISUALIZATION
% ============================

% Figure 1: Individual Model Predictions
figure('color', [1 1 1], 'Position', [100, 100, 1500, 400]);
plot(age, Result_DP, 'r', 'LineWidth', 1.5); hold on;
plot(age, smooth(Result_Bag), 'y', 'LineWidth', 1.5);
plot(age, smooth(Result_RF), 'g', 'LineWidth', 1.5);
plot(age, smooth(Result_SVM), 'b', 'LineWidth', 1.5);
plot(age, smooth(Result_Boosting), 'm', 'LineWidth', 1.5);
plot(age, smooth(Y_weighted), 'k', 'LineWidth', 2.5); % Ensemble
xlabel('Age (kyr BP)', 'FontName', 'Times New Roman');
ylabel('Weathering (×10^{12} mol/yr)', 'FontName', 'Times New Roman');
legend('GANs-GRU-LSTM', 'Bagging', 'Random Forest', 'SVM', 'Boosting', ...
       'Weighted Ensemble', 'Location', 'best');
grid on;

% Figure 2: Ensemble with Uncertainty Range
all_predictions = [Result_DP', Result_Bag, Result_RF, Result_SVM, Result_Boosting];
max_values = max(all_predictions, [], 2);
min_values = min(all_predictions, [], 2);

figure('color', [1 1 1], 'Position', [100, 100, 1500, 400]);
fill([age; flip(age)], [max_values; flip(min_values)], ...
     [0.8, 0.9, 1], 'EdgeColor', 'none', 'FaceAlpha', 0.5); hold on;
plot(age, Y_weighted, 'b', 'LineWidth', 2.5);
xlabel('Age (kyr BP)', 'FontName', 'Times New Roman');
ylabel('Weathering (×10^{12} mol/yr)', 'FontName', 'Times New Roman');
legend('Model Range (Min-Max)', 'Weighted Ensemble', 'Location', 'best');
grid on;

% =========================================================================
% CITATION REQUIREMENTS:
% =========================================================================
% If you use this code in your research, please cite:
% 1. Our main manuscript (when published)
% 2. The original machine learning models used (as appropriate)
% 3. The input data sources (as described in our methods)
%
% =========================================================================
% END OF PROGRAM
% =========================================================================